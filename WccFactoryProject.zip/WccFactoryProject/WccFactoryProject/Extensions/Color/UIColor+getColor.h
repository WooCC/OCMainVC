//
//  UIColor+getColor.h
//  WccFactoryProject
//
//  Created by 吴承炽 on 2018/6/19.
//  Copyright © 2018年 Wcc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (getColor)
+ (UIColor *)backGroundLightGrayColor;
@end
