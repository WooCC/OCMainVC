//
//  UIView+Boarder.m
//  Qu114Project
//
//  Created by 吴承炽 on 2017/7/26.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import "UIView+Boarder.h"

@implementation UIView (Boarder)
@dynamic borderWhich;
- (void)setBorderWhich:(ZJViewBorder)borderWhich {
    CGFloat bh = self.layer.borderWidth;
    
    if (borderWhich & DeleteBorderBottom) {
//      [self addBottomBorder:self borderHeight:bh];
        [self addLeftBorder:self borderHeight:bh];
        [self addRightBorder:self borderHeight:bh];
        [self addTopBorder:self borderHeight:bh];
    }
    if (borderWhich & DeleteBorderLeft) {
        [self addBottomBorder:self borderHeight:bh];
//        [self addLeftBorder:self borderHeight:bh];
        [self addRightBorder:self borderHeight:bh];
        [self addTopBorder:self borderHeight:bh];
    }
    if (borderWhich & DeleteBorderRight) {
        [self addBottomBorder:self borderHeight:bh];
        [self addLeftBorder:self borderHeight:bh];
//        [self addRightBorder:self borderHeight:bh];
        [self addTopBorder:self borderHeight:bh];
    }
    if (borderWhich & DeleteBorderTop) {
        [self addBottomBorder:self borderHeight:bh];
        [self addLeftBorder:self borderHeight:bh];
        [self addRightBorder:self borderHeight:bh];
//        [self addTopBorder:self borderHeight:bh];
    }
    if (borderWhich & AddAllBorder) {
        [self addBottomBorder:self borderHeight:bh];
        [self addLeftBorder:self borderHeight:bh];
        [self addRightBorder:self borderHeight:bh];
        [self addTopBorder:self borderHeight:bh];
    }
    self.layer.borderWidth = 0;
}
- (void)addTopBorder:(UIView *)vi borderHeight:(CGFloat)bh {
    CGColorRef col = vi.layer.borderColor;
    if (vi.layer.borderWidth > 1000 || vi.layer.borderWidth == 0) {
        bh = 1;
    }
    else
        bh = vi.layer.borderWidth;
    CALayer *border = [CALayer layer];
    border.frame = CGRectMake(0, 0, vi.frame.size.width, bh);
    border.backgroundColor = col;
    [vi.layer addSublayer:border];
}
- (void)addLeftBorder:(UIView *)vi borderHeight:(CGFloat)bh{
    CGColorRef col = vi.layer.borderColor;
    if (vi.layer.borderWidth > 1000 || vi.layer.borderWidth == 0) {
        bh = 1;
    }
    else
        bh = vi.layer.borderWidth;
    CALayer *border = [CALayer layer];
    border.frame = CGRectMake(0, 0, bh, vi.frame.size.height);
    border.backgroundColor = col;
    [vi.layer addSublayer:border];
}
- (void)addBottomBorder:(UIView *)vi borderHeight:(CGFloat)bh{
    CGColorRef col = vi.layer.borderColor;
    if (vi.layer.borderWidth > 1000 || vi.layer.borderWidth == 0) {
        bh = 1;
    }
    else
        bh = vi.layer.borderWidth;
    CALayer *border = [CALayer layer];
    border.frame = CGRectMake(0, vi.frame.size.height-bh, vi.frame.size.width, bh);
    border.backgroundColor = col;
    [vi.layer addSublayer:border];
}
- (void)addRightBorder:(UIView *)vi borderHeight:(CGFloat)bh{
    CGColorRef col = vi.layer.borderColor;
    if (vi.layer.borderWidth > 1000 || vi.layer.borderWidth == 0) {
        bh = 1;
    }
    else
        bh = vi.layer.borderWidth;
    CALayer *border = [CALayer layer];
    border.frame = CGRectMake(vi.frame.size.width-bh, 0, bh, vi.frame.size.height);
    border.backgroundColor = col;
    [vi.layer addSublayer:border];
}

@end
