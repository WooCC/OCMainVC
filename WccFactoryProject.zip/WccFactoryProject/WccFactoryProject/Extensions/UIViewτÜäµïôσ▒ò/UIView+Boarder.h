//
//  UIView+Boarder.h
//  Qu114Project
//
//  Created by 吴承炽 on 2017/7/26.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger, ZJViewBorder) {
    DeleteBorderTop = 1<<1,
    DeleteBorderLeft = 1<<2,
    DeleteBorderBottom = 1<<3,
    DeleteBorderRight = 1<<4,
    AddAllBorder = 1<<5
};
@interface UIView (Boarder)
@property (nonatomic, assign) ZJViewBorder borderWhich;
@end
