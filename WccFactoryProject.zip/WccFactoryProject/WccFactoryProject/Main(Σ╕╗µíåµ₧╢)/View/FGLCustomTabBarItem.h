//
//  FGLCustomTabBarItem.h
//  疯购了
//
//  Created by 吴承炽 on 2016/12/14.
//  Copyright © 2016年 申丰科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FGLCustomTabBarItem : UIButton

@end
