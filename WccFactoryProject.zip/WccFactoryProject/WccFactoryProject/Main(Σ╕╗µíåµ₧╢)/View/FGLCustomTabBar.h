//
//  FGLCustomTabBar.h
//  疯购了
//
//  Created by 吴承炽 on 2016/12/14.
//  Copyright © 2016年 申丰科技. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FGLCustomTabBar;
@protocol FGLCustomTabBarDelegate <NSObject>
- (void)customTabBar:(FGLCustomTabBar *)tabbar didClickAtIndex:(NSInteger)index;
@end

@interface FGLCustomTabBar : UIView
@property (nonatomic, weak) id<FGLCustomTabBarDelegate> delegate;
XMGSingletonH(FGLCustomTabBar)
- (void)addButtonWithNormalImageName:(NSString *)normalImageName selectedImageName:(NSString *)selectedImageName selectedTitle:(NSString *)selectedTitle;
- (void)clickBtn:(UIButton *)btn;
@end
