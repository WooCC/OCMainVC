//
//  FGLCustomTabBar.m
//  疯购了
//
//  Created by 吴承炽 on 2016/12/14.
//  Copyright © 2016年 申丰科技. All rights reserved.
//

#import "FGLCustomTabBar.h"
#import "FGLCustomTabBarItem.h"

@interface FGLCustomTabBar ()

@property (nonatomic, strong) UIButton *selectedButton;

@end

@implementation FGLCustomTabBar
XMGSingletonM(FGLCustomTabBar)
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        self.backgroundColor = [UIColor grayColor];
    }
    return self;
}

- (void)addButtonWithNormalImageName:(NSString *)normalImageName selectedImageName:(NSString *)selectedImageName selectedTitle:(NSString *)selectedTitle{
    UIButton *btn = [[FGLCustomTabBarItem alloc]init];
    // 如果加了选中状态，就不会起作用
    btn.adjustsImageWhenHighlighted = NO;
    [self setButtonContentCenter:btn];
    UIImage *image1 = [UIImage imageNamed:normalImageName];
    image1 = [image1 imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    // 设置背景图片
    btn.tintColor = [UIColor lightGrayColor];
    [btn setImage:image1 forState:UIControlStateNormal];

    // 设置选中的背景图片
    [btn setImage:[UIImage imageNamed:selectedImageName] forState:UIControlStateSelected];
    
    
    
    btn.titleLabel.textColor = [UIColor lightGrayColor];
    btn.titleLabel.font = [UIFont systemFontOfSize: 13.0];
    [btn setTitle:selectedTitle forState:UIControlStateNormal];
    
    
    // 把按钮添加到view上面
    [self addSubview:btn];
    
    // 添加一个点击事件
    [btn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchDown];
}

-(void)setButtonContentCenter:(UIButton *) btn

{
    
    CGSize imgViewSize,titleSize,btnSize;
    
    UIEdgeInsets imageViewEdge,titleEdge;
    
    CGFloat heightSpace = -10.0f;
      //设置按钮内边距
    
    imgViewSize = btn.imageView.bounds.size;
    
    titleSize = btn.titleLabel.bounds.size;
    
    btnSize = btn.bounds.size;
    
    imageViewEdge = UIEdgeInsetsMake(heightSpace,-heightSpace*2, btnSize.height -imgViewSize.height - heightSpace, - titleSize.width);
    
    [btn setImageEdgeInsets:imageViewEdge];
    
    titleEdge = UIEdgeInsetsMake(imgViewSize.height -heightSpace*1.5, heightSpace*2.5, 0.0, 0.0);
    
    [btn setTitleEdgeInsets:titleEdge];
    
}

- (void)clickBtn:(UIButton *)btn {
    self.selectedButton.tintColor = [UIColor lightGrayColor];
    self.selectedButton.layer.cornerRadius = self.selectedButton.frame.size.width *0.2;
    self.selectedButton.backgroundColor = self.backgroundColor;
    // 取消上一个被选中的按钮
    self.selectedButton.selected = NO;
    // 选中当前点击 的按钮
    btn.selected = YES;
    // 记录当前点击的按钮
    self.selectedButton = btn;
    self.selectedButton.tintColor = [UIColor whiteColor];
//    self.selectedButton.layer.cornerRadius = self.selectedButton.frame.size.width *0.2;
    self.selectedButton.backgroundColor = [UIColor grayColor];
    // 代理回调
    if (self.delegate && [self.delegate respondsToSelector:@selector(customTabBar:didClickAtIndex:)]) {
        [self.delegate customTabBar:self didClickAtIndex:btn.tag];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    // btn 宽度
    CGFloat btnWidth = self.frame.size.width / self.subviews.count;
    // btn 高度
    CGFloat btnHeight = self.frame.size.height;
    
    // btn 的 y值
    CGFloat btnY = 0;
    
    // 设置按钮的frame
    for (int i = 0; i < self.subviews.count; ++i) {
        UIButton *btn = self.subviews[i];
        if (i == 0) {
            //            // 默认选中第一个
            //            btn.selected = YES;
            //            // 记录当前选中的按钮
            //            self.selectedButton = btn;
            
            [self clickBtn:btn];
        }
        // 设置tag
        btn.tag = i;
        
        // btnX
        CGFloat btnX = btnWidth * i;
        // 设置frame
        btn.frame = CGRectMake(btnX, btnY, btnWidth, btnHeight);
        btn.layer.cornerRadius = btnWidth * 0.2;
//        [self.btnArray addObject:btn];
    }
}
//-(NSMutableArray *)btnArray
//{
//    if (!_btnArray) {
//        _btnArray = [NSMutableArray array];
//    }
//    return _btnArray;
//}


@end
