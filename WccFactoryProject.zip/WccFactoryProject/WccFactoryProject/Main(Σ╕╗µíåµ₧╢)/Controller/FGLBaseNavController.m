//
//  FGLBaseNavController.m
//  疯购了
//
//  Created by 吴承炽 on 2016/12/14.
//  Copyright © 2016年 申丰科技. All rights reserved.
//

#import "FGLBaseNavController.h"

@interface FGLBaseNavController ()

@end

@implementation FGLBaseNavController

+ (void)load
{
    
}

// 当类第一次使用的时候会调用 - 当第一次使用的时候，作一些对象或者属性的初始化工作
+ (void)initialize {
    //    NSLog(@"initialize");
    if (self == [FGLBaseNavController class]) {
        //         NSLog(@"initialize");
        // 获取全局的导航栏 - 只需要设置一次整个项目都起作用
        UINavigationBar *bar = [UINavigationBar appearance];
        // 设置背景图片
                [bar setBackgroundImage:[UIImage imageNamed:@"NavBar64"] forBarMetrics:UIBarMetricsDefault];
        
#pragma mark ----看起来没什么用
        // 设置导航栏背景色
        NSDictionary *att = @{NSForegroundColorAttributeName:[UIColor whiteColor],
                              NSFontAttributeName:[UIFont systemFontOfSize:16]};
        
        // 设置标题颜色
        [bar setTitleTextAttributes:att];
        
        // 设置子控件的颜色 - 返回按钮也会变白色
        bar.tintColor = [UIColor whiteColor];
        
    }
}


- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    viewController.hidesBottomBarWhenPushed = YES;
    [super pushViewController:viewController animated:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

@end
