//
//  FGLRootViewController.m
//  疯购了
//
//  Created by 吴承炽 on 2016/12/14.
//  Copyright © 2016年 申丰科技. All rights reserved.
//

#import "FGLRootViewController.h"
#import "FGLCustomTabBar.h"
#import "FGLCustomTabBarItem.h"
#import "PersonallerController.h"
#import "HomeController.h"
#import "IssuanceController.h"
@interface FGLRootViewController ()<FGLCustomTabBarDelegate>
@end

@implementation FGLRootViewController

////这里直接让当前类变单例
//XMGSingletonM(FGLRootViewController)

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadViewControllers];
    [self setupCustomTabbar];
//
//
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doNotification:) name:@"通知" object:nil];
}
-(void)doNotification:(NSNotification*)notification
{
    //接收通知
//    NSDictionary *dic = notification.userInfo;
//    NSString *value = dic[@"key"];
//    if ([value isEqualToString:@"1"]) {
//        FGLCustomTabBar *customTabbar = [[FGLCustomTabBar alloc]init];
//        [self customTabBar:customTabbar didClickAtIndex:1];
//        [customTabbar clickBtn:customTabbar.subviews[1]];
//    }
//    if ([value isEqualToString:@"3"]) {
//
//        FGLCustomTabBar *customTabbar = [[FGLCustomTabBar alloc]init];
//        [self customTabBar:customTabbar didClickAtIndex:3];
//        [customTabbar clickBtn:customTabbar.subviews[3]];
//
//        FGLNewsViewController *nvc = [[FGLNewsViewController alloc]init];
//        nvc.senderTag = 105;
//        [nvc.newsTableview.mj_header beginRefreshing];
//
//
//        [nvc.newsFilterView.button99 setTitleColor:[UIColor colorWithRed:111/255.0 green:111/255.0 blue:111/255.0 alpha:1] forState:UIControlStateNormal];
//         [nvc.newsFilterView.button104 setTitleColor:[UIColor colorWithRed:200/255.0 green:0/255.0 blue:0/255.0 alpha:1] forState:UIControlStateNormal];
//}

    

    
#pragma mark -----我这里移除通知中心，这样才能无限跳转
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"通知" object:nil];
}

//-(FGLNewFilterView * )newsFilterView
//{
//    if(!_newsFilterView) {
//        _newsFilterView = [FGLNewFilterView  newsFilterView];
//        [_newsFilterView.button99 setTitleColor:[UIColor colorWithRed:200/255.0 green:0/255.0 blue:0/255.0 alpha:1] forState:UIControlStateNormal];
//        _newsFilterView.buttonTag1 = _newsFilterView.button99.tag;
//    }
//    return _newsFilterView;
//}

// 初始化自定义tabbar
- (void)setupCustomTabbar {
    // 移除旧的tabbar
    //    [self.tabBar removeFromSuperview];
    
    FGLCustomTabBar *customTabbar = [[FGLCustomTabBar alloc]init];
    
    // 设置代理
    customTabbar.delegate = self;
    // 设置frame
    customTabbar.frame = self.tabBar.bounds;
    
    // 动态添加按钮
    for (int i = 0; i <  self.viewControllers.count; ++i) {
        // 拼接图片名字
        NSString *normalImageName = [NSString stringWithFormat:@"Tabbar%zd",i+1];
        
        // 拼接选中的图片名字
        NSString *selectedImageName = [NSString stringWithFormat:@"Tabbar%zdSel",i+1];
        NSString *title = [NSString string];
        switch (i) {
            case 0:title = @"首页";break;
            case 1:title = @"发布";break;
            case 2:title = @"个人";break;
            default:
                break;
        }
        

        [customTabbar addButtonWithNormalImageName:normalImageName selectedImageName:selectedImageName selectedTitle:title];

    }
    
   
    [self.tabBar addSubview:customTabbar];
}

- (void)loadViewControllers {
    UINavigationController *homeMainVC = [[UINavigationController alloc]initWithRootViewController:[HomeController new]];
    UINavigationController *issuanceMainVC = [[UINavigationController alloc]initWithRootViewController:[IssuanceController new]];
    UINavigationController *personalMainVC = [[UINavigationController alloc]initWithRootViewController:[PersonallerController new]];
    // 把控制器加到子控制器中
    self.viewControllers = @[homeMainVC, issuanceMainVC, personalMainVC];
    
    
}

- (UINavigationController *)controllWithStoryboardName:(NSString *)name {
    UIStoryboard *sb = [UIStoryboard storyboardWithName:name bundle:nil];
    UINavigationController *nav = [sb instantiateInitialViewController];
    
    return nav;
}

#pragma mark - 自定义的tabbar代理方法
- (void)customTabBar:(FGLCustomTabBar *)tabbar didClickAtIndex:(NSInteger)index {
    self.selectedIndex = index;
    //这里应该还会有BUG
    if (self.selectedIndex == 3) {
//        FGLNewsViewController *nvc = [[FGLNewsViewController alloc]init];
//        nvc.senderTag = 99;
//        [nvc.newsTableview.mj_header beginRefreshing];
//
//
//        [nvc.newsFilterView.button104 setTitleColor:[UIColor colorWithRed:111/255.0 green:111/255.0 blue:111/255.0 alpha:1] forState:UIControlStateNormal];
//        [nvc.newsFilterView.button99 setTitleColor:[UIColor colorWithRed:200/255.0 green:0/255.0 blue:0/255.0 alpha:1] forState:UIControlStateNormal];
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
