
#import "NetRequestClass.h"
#import <AFNetworking.h>

#ifndef Indicator
#define Indicator(BOOL) [UIApplication sharedApplication].networkActivityIndicatorVisible = BOOL
#endif

@implementation NetRequestClass

#pragma mark - GET请求方式
+ (void)netRequestGETWithRequestURL:(NSString *)requestURLString
                     WithParameters:(NSDictionary *)parameters
               WithReturnValueBlock:(ReturnValueBlock)block
                     WithErrorBlock:(ErrorBlock)errorBlock
                   WithFailureBlock:(FailureBlock)failureBlock
{
    Indicator(YES);
    
    NSLog(@"requestURLString:%@", requestURLString);
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer]; // 不加上这句话，会报“Request failed: unacceptable content-type: text/plain”错误，因为我们要获取text/plain类型数据
    [manager GET:requestURLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [self dealWithResponseObject:responseObject ReturnValueBlock:block ErrorBlock:errorBlock];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [self failureWithError:error FailureBlock:failureBlock];
    }];
}

#pragma mark - POST请求方式
+ (void)netRequestPOSTWithRequestURL:(NSString *)requestURLString
                      WithParameters:(NSDictionary *)parameters
                WithReturnValueBlock:(ReturnValueBlock)block
                      WithErrorBlock:(ErrorBlock)errorBlock
                    WithFailureBlock:(FailureBlock)failureBlock
{
    Indicator(YES);
    
    NSLog(@"requestURLString:%@", requestURLString);
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer]; // 不加上这句话，会报“Request failed: unacceptable content-type: text/plain”错误，因为我们要获取text/plain类型数据
    [manager POST:requestURLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        [self dealWithResponseObject:responseObject ReturnValueBlock:block ErrorBlock:errorBlock];
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [self failureWithError:error FailureBlock:failureBlock];
        
        NSLog(@"%@",error);
    }];
}

+ (void)dealWithResponseObject:(id _Nullable)responseObject ReturnValueBlock:(ReturnValueBlock)block ErrorBlock:(ErrorBlock)errorBlock
{
    Indicator(NO);
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers | NSJSONReadingMutableLeaves error:nil];
    NSLog(@"dic:%@", dic);
    /**
     *  在这做判断如果有dic里有errorCode
     *  调用errorBlock(dic)
     *  没有errorCode则调用block(dic)
     */
    NSInteger code = [dic[@"StateCode"] integerValue];
    NSString * loginstatus = [NSString stringWithFormat:@"%zd",code];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:loginstatus forKey:@"loginstatus"];
    
    NSLog(@"看看信息：%@",dic[@"Message"]);
    NSLog(@"%zd",code);
    
    if (code != 1) {
#ifdef DEBUG
        //                [kKeyWindow makeToast:MMGLocalizedString(errcode) duration:kToastDuration position:CSToastPositionBottom];
#else
        //        [SVProgressHUD showInfoWithStatus:MMGLocalizedString(errcode)];
#endif
        if (errorBlock) {
            errorBlock(code, dic[@"Message"]);
            NSLog(@"这里:%@",dic[@"Message"]);
        }
        if (code == 403) {
//            [JCWindows makeToast:[NSString stringWithFormat:@"%@",dic[@"Message"]]
//                        duration:1.
//                        position:CSToastPositionCenter];
            return;
        }
        if (code == 500) {
//            [JCWindows makeToast:[NSString stringWithFormat:@"%@",dic[@"Message"]]
//                        duration:1.
//                        position:CSToastPositionCenter];
            return;
        }
        //        if (errcode == 2002 || errcode == 2003) { // 令牌查不到或过期
        //            [MMGUserInfoArchiveModel deleteUserInfoArchiveModel]; // 删除归档
        //            [UIAlertView alertWithHandler:^(NSInteger buttonIndex) {
        //                if ([kKeyWindow.topMostController isKindOfClass:[MMGTabBarController class]]) {
        //                    MMGTabBarController *tabBarVC = (MMGTabBarController *)[kKeyWindow topMostController];
        //                    [tabBarVC setSelectedIndex:0];
        //                    [tabBarVC.childViewControllers makeObjectsPerformSelector:@selector(popToRootViewControllerAnimated:) withObject:@NO];
        //                    if (buttonIndex == 1) { // 重新登录
        //                        [tabBarVC presentLoginViewController];
        //                    }
        //                }
        //            } title:@"提示" message:MMGLocalizedString(errcode) cancelButtonTitle:nil otherButtonTitles:@"返回首页", @"重新登录", nil];
        //        }
        //        return;
    }
    if (block) {
//        if ([dic[@"result"] isKindOfClass:[NSMutableArray class]]) {
//            if (![dic[@"result"] count]) {
//#ifdef DEBUG
//                //                [kKeyWindow makeToast:kServerDataZero duration:kToastDuration position:CSToastPositionBottom];
//#endif
//            }
//        }
        
        block(dic[@"Result"]);
        
//        NSLog(@"%@",dic[@"Result"]);
//        dic[@"Result"][@"TimeSignature"];
        
#pragma mark ---- 取出当前登录的时间
//        NSLog(@"%@",dic[@"Result"][@"TimeSignature"]);
    
       
        
        
    }
}

+ (void)failureWithError:(NSError *)error FailureBlock:(FailureBlock)failureBlock
{
    Indicator(NO);
#ifdef DEBUG
    
    
    NSLog(@"我想看失败的信息:%@",failureBlock);
    //    [SVProgressHUD dismiss];
    //    [kKeyWindow makeToast:[error localizedDescription] duration:kToastDuration position:CSToastPositionBottom];
    
#else
    //    [SVProgressHUD showErrorWithStatus:[error localizedDescription]];
#endif
    if (failureBlock) {
//        failureBlock(code, dic[@"Message"]);

        failureBlock();
        
    }
}

@end
