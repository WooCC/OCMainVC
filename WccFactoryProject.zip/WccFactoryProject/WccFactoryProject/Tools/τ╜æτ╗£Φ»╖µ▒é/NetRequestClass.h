
#import <Foundation/Foundation.h>

// 定义返回请求数据的block类型
typedef void(^ReturnValueBlock)(id returnValue);
typedef void(^ErrorBlock)(NSInteger errorCode, NSString *returnValue);
typedef void(^FailureBlock)();

@interface NetRequestClass : NSObject

#pragma mark - GET请求方式
+ (void)netRequestGETWithRequestURL:(NSString *)requestURLString
                     WithParameters:(NSDictionary *)parameters
               WithReturnValueBlock:(ReturnValueBlock)block
                     WithErrorBlock:(ErrorBlock)errorBlock
                   WithFailureBlock:(FailureBlock)failureBlock;

#pragma mark - POST请求方式
+ (void)netRequestPOSTWithRequestURL:(NSString *)requestURLString
                      WithParameters:(NSDictionary *)parameters
                WithReturnValueBlock:(ReturnValueBlock)block
                      WithErrorBlock:(ErrorBlock)errorBlock
                    WithFailureBlock:(FailureBlock)failureBlock;

@end
