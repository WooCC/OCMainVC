//
//  KeyChainTools.h
//  Qu114Project
//
//  Created by 吴承炽 on 2017/9/4.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>
@interface KeyChainTools : NSObject

// save username and password to keychain
+ (void)save:(NSString *)service data:(id)data;

// take out username and passwore from keychain
+ (id)load:(NSString *)service;

// delete username and password from keychain
+ (void)delete:(NSString *)service;

+(void)update:(NSString *)service andNewData:(NSString *)newData;

@end
