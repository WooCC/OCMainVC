//
//  DataSingleton.h
//  五种传值的总结
//
//  Created by lanou on 15/8/2.
//  Copyright (c) 2015年 yxy. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "AreaModel.h"
@interface DataSingleton : NSObject
@property(nonatomic,copy)NSString *cityCode;

@property(nonatomic,strong)NSMutableArray * district_name_Arr;
@property(nonatomic,strong)NSMutableArray * district_ID_Arr;
@property(nonatomic,strong)NSMutableArray * district_code_Arr;
@property(nonatomic,strong)NSMutableArray * am_area_Arr;

@property(nonatomic,strong)NSMutableArray * alias_name_ARR;
@property(nonatomic,strong)NSMutableArray * alias_url_ARR;

@property(nonatomic,strong)NSMutableArray * country_Name_Arr;
@property(nonatomic,strong)NSMutableArray * country_Value_Arr;

@property(nonatomic,strong)NSMutableArray * moreChoice_Name_Arr;
@property(nonatomic,strong)NSMutableArray * moreChoice_Value_Arr;

//@property(nonatomic,strong)AreaModel * am;
@property(nonatomic,strong)NSMutableArray * am_lv2_Arr;
@property(nonatomic,strong)NSMutableArray * amArr;
@property(nonatomic,strong)NSMutableArray * area_Arr;

+(instancetype)dataSingleton;
@end

