//
//  DataSingleton.m
//  五种传值的总结
//
//  Created by lanou on 15/8/2.
//  Copyright (c) 2015年 yxy. All rights reserved.
//

#import "DataSingleton.h"

@implementation DataSingleton
static DataSingleton *dataSingleton = nil;
+(instancetype)dataSingleton
{
    if (dataSingleton == nil) {
        dataSingleton = [[DataSingleton alloc]init];
    }
    return dataSingleton;
}
@end
