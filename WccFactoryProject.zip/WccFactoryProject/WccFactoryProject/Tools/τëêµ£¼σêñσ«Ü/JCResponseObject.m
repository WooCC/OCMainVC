//
//  JCResponseObject.m
//  JCPay
//
//  Created by 吴承炽 on 2017/3/9.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import "JCResponseObject.h"

@implementation JCResponseObject

@end
