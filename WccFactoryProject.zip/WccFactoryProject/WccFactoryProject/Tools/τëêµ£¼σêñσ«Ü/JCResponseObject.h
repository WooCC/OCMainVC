//
//  JCResponseObject.h
//  JCPay
//
//  Created by 吴承炽 on 2017/3/9.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCResponseObject : NSObject
@property (assign, nonatomic) NSInteger code;
@property (strong, nonatomic) NSString *message;
@property (strong, nonatomic) NSDictionary *result;
@end
