//
//  PassWordField.m
//  Qu114Project
//
//  Created by 吴承炽 on 2017/11/9.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import "PassWordField.h"

@implementation PassWordField
//控制清除按钮的位置
-(CGRect)clearButtonRectForBounds:(CGRect)bounds
{
   return CGRectMake(bounds.origin.x + bounds.size.width - 100, bounds.origin.y, bounds.size.height, bounds.size.height);
}
//控制左视图位置
- (CGRect)leftViewRectForBounds:(CGRect)bounds
{
    CGFloat y =(bounds.size.height - 30)*0.5;
    CGRect inset = CGRectMake(bounds.size.width - 40, y , 30, 30);
    return inset;
}
//控制右视图位置
- (CGRect)rightViewRectForBounds:(CGRect)bounds
{
    CGFloat y =(bounds.size.height - 30)*0.5;
    CGRect inset = CGRectMake(bounds.size.width - 40, y , 30, 30);
    return inset;
}
//控制显示文本的位置
-(CGRect)textRectForBounds:(CGRect)bounds
{
    CGRect inset = CGRectMake(bounds.origin.x+10, bounds.origin.y, bounds.size.width -10, bounds.size.height);
    return inset;
    
}
//控制编辑文本的位置
-(CGRect)editingRectForBounds:(CGRect)bounds
{
    CGRect inset = CGRectMake(bounds.origin.x +10, bounds.origin.y, bounds.size.width -10, bounds.size.height);
    return inset;
}

- (CGRect)placeholderRectForBounds:(CGRect)bounds
{
    CGRect inset = CGRectMake(bounds.origin.x +10, bounds.origin.y, bounds.size.width -10, bounds.size.height);
    return inset;
}

@end
