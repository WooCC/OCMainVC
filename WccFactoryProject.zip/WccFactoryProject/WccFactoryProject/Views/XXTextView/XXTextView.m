//
//  XXTextView.m
//  Remember
//
//  Created by Jason on 2017/5/21.
//  Copyright © 2017年 ifelseboyxx. All rights reserved.
//

#import "XXTextView.h"

@interface XXTextView ()

@property (weak, nonatomic) UILabel *placeholderLabel;

@end

@implementation XXTextView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setUp];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (!self) return nil;
    [self setUp];
    return self;
}

- (void)setUp {
//    CGFloat width = self.frame.size.width;
//    CGFloat height = self.frame.size.height;
    
    
    
    UILabel *placeholderLabel = [[UILabel alloc] init];
    placeholderLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_placeholderLabel = placeholderLabel];
    
//    self.xx_placeholderColor = JCLightGray;
    self.xx_placeholderFont = [UIFont systemFontOfSize:16.0f];
    self.font = [UIFont systemFontOfSize:16.0f];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:self];
    
//    UIView * lineA = [[UIView alloc]initWithFrame:CGRectMake(0, 0, width, 1)];
//    lineA.backgroundColor = [UIColor orangeColor];
//    [self addSubview:lineA];
//    [lineA mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self);
//        make.left.equalTo(self);
//        make.size.mas_equalTo(CGSizeMake(width, 1));
//    }];
}

#pragma mark - UITextViewTextDidChangeNotification

- (void)textDidChange {
    self.placeholderLabel.hidden = self.hasText;
}


- (void)setText:(NSString *)text {
    [super setText:text];
    
    [self textDidChange];
}

- (void)setAttributedText:(NSAttributedString *)attributedText {
    [super setAttributedText:attributedText];
    
    [self textDidChange];
}


- (void)setXx_placeholderFont:(UIFont *)xx_placeholderFont {
    _xx_placeholderFont = xx_placeholderFont;
    self.placeholderLabel.font = xx_placeholderFont;
    [self setNeedsLayout];
}

- (void)setXx_placeholder:(NSString *)xx_placeholder {
    _xx_placeholder = [xx_placeholder copy];
    
    self.placeholderLabel.text = xx_placeholder;
    
    [self setNeedsLayout];
    
}


- (void)setXx_placeholderColor:(UIColor *)xx_placeholderColor {
    _xx_placeholderColor = xx_placeholderColor;
    self.placeholderLabel.textColor = xx_placeholderColor;
}


- (void)layoutSubviews {
    [super layoutSubviews];
//    CGFloat height = self.frame.size.height;
    CGRect frame = self.placeholderLabel.frame;
    frame.origin.y = self.textContainerInset.top;
    
    frame.origin.x = self.textContainerInset.left+6.0f;
    frame.size.width = self.frame.size.width - self.textContainerInset.left*2.0;
    
    CGSize maxSize = CGSizeMake(frame.size.width, MAXFLOAT);
    frame.size.height = [self.xx_placeholder boundingRectWithSize:maxSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.placeholderLabel.font} context:nil].size.height;
//    frame.origin.y = height/2 - frame.size.height/2;
    self.placeholderLabel.frame = frame;
}

- (void)dealloc {
    
    [[NSNotificationCenter defaultCenter] removeObserver:UITextViewTextDidChangeNotification];
}

@end
