//
//  UILabel+SpaceForText.m
//  Qu114Project
//
//  Created by 吴承炽 on 2017/7/5.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import "UILabel+SpaceForText.h"
#import <CoreText/CoreText.h>
@implementation UILabel (SpaceForText)
- (void)changeAlignmentRightandLeftwithWidth:(CGFloat)width{
    
    CGRect textSize = [self.text boundingRectWithSize:CGSizeMake(self.frame.size.width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingTruncatesLastVisibleLine |NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : self.font} context:nil];
 
    CGFloat margin = (width - textSize.size.width) / (self.text.length - 1);

    NSNumber *number = [NSNumber numberWithFloat:margin];
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc]initWithString:self.text];
    [attributeString addAttribute:(id)kCTKernAttributeName value:number range:NSMakeRange(0, self.text.length - 1)];
    self.attributedText = attributeString;
    
}
@end
