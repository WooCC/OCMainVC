//
//  UILabel+SpaceForText.h
//  Qu114Project
//
//  Created by 吴承炽 on 2017/7/5.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (SpaceForText)
//让文字中间出现空格
- (void)changeAlignmentRightandLeftwithWidth:(CGFloat)width;
@end
