//
//  LinePageController.m
//  SFShoppingCenter
//
//  Created by 吴承炽 on 2017/12/26.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import "LinePageController.h"
#define dotW JCScrean_W/4 // 圆点宽
#define dotH 3  // 圆点高
#define magrin  JCScrean_W/4  // 圆点间距130
@implementation LinePageController

- (void) setCurrentPage:(NSInteger)page {
    
    [super setCurrentPage:page];
    
    for (NSUInteger subviewIndex = 0; subviewIndex < [self.subviews count]; subviewIndex++) {
        
        UIImageView* subview = [self.subviews objectAtIndex:subviewIndex];
        
        CGSize size;
        
        size.height = dotH;
        
        size.width = dotW;
        
        [subview setFrame:CGRectMake(subview.frame.origin.x, subview.frame.origin.y,size.width,size.height)];
    }
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    //计算圆点间距
    CGFloat marginX = dotW + magrin;
    
    //计算整个pageControll的宽度
    CGFloat newW = (self.subviews.count - 1 ) * marginX;
    
    
    //设置新frame
//    self.frame = CGRectMake(SFScrean_W/2-(newW + dotW)/2, self.frame.origin.y, newW + dotW, self.frame.size.height);
    self.frame = CGRectMake((JCScrean_W - (2*dotW + magrin))/2, 30, newW + dotW, self.frame.size.height);
    //遍历subview,设置圆点frame
    for (int i=0; i<[self.subviews count]; i++) {
        UIImageView* dot = [self.subviews objectAtIndex:i];
        
        if (i == self.currentPage) {
            [dot setFrame:CGRectMake(i * marginX, dot.frame.origin.y, dotW, dotH)];
        }else {
            [dot setFrame:CGRectMake(i * marginX, dot.frame.origin.y, dotW, dotH)];
        }
    }
}

@end
