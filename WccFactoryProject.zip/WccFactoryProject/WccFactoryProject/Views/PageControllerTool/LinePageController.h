//
//  LinePageController.h
//  SFShoppingCenter
//
//  Created by 吴承炽 on 2017/12/26.
//  Copyright © 2017年 申丰科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LinePageController : UIPageControl
- (void) setCurrentPage:(NSInteger)page;
@end
